<template>
<!-- 基础数据--管材 -->
<div>
    管材
</div>

</template>    
<script>
    export default {
        name:'basicDataPipe',
        data () {
            return {};
        }
    }
</script>
<style  scoped>

</style>