<template>
<!-- 调节阀 -->
<div class="regulatingValveBox">
    调节阀
</div>
</template>    
<script>

    export default {
        name:'regulatingValve',
        data () {
            return {};
        }
    }
</script>
<style  scoped>

</style>