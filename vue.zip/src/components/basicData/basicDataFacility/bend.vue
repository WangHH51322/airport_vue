<template>
<!-- 弯头 -->
<div class="bendBox">
    弯头
</div>
</template>    
<script>

    export default {
        name:'bend',
        data () {
            return {};
        }
    }
</script>
<style  scoped>

</style>