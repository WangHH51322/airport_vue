<template>
<!-- 止回阀 -->
<div class="checkValveBox">
    止回阀
</div>
</template>    
<script>

    export default {
        name:'checkValve',
        data () {
            return {};
        }
    }
</script>
<style  scoped>

</style>