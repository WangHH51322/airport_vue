<template>
<!-- 截断阀 -->
<div class="shutOffValveBox">
    截断阀
</div>
</template>    
<script>

    export default {
        name:'shutOffValve',
        data () {
            return {};
        }
    }
</script>
<style  scoped>

</style>