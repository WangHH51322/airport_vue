<template>
<!-- 二级功能导航1 -->
<div>
    <div class="box2 b-button">直管段</div>
    <div class="box2 b-button">弯头/阀</div>
    <div class="box2 b-button">加油设备</div>
    <div class="box2 ">Excel导入</div>
</div>

</template>

<script>
    export default {
        name:'navigation1'
    }
</script>
<style scope>
.b-button {
    border-bottom: solid 1px black;
}
.box2 {
    width: 240px;
    height: 65px;
    font-size: 20px;
    line-height: 20px;
    padding: 20px;
    text-align: center;
}
</style>