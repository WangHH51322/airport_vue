<template>
<!--  属性参数 attribute   稳态-->

<div>
    <div class="shux-box">
        设备参数设置
    </div>

    <div class="shux-box">
        油料性质参数设置
    </div>

    <div class="shux-box">
        边界条件设置
    </div>
</div>

</template>

<script>
    export default {
        name:'attribute1'
    }
</script>
<style scope>
/* 属性盒子 */
.shux-box {
    border: 0.5px solid black;
    width: 255px;
    height: 125px;
    /* padding: 0.5px; */
}
</style>