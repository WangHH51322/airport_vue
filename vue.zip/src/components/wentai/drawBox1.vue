<template>
<div>
    <div class="icon-box">
        <i class="el-icon-edit"></i>
        <i class="el-icon-share"></i>
        <i class="el-icon-delete"></i>
    </div>
</div>
</template>    

<script>
    export default {
        name:'drawBox1'
    }
</script>
<style  scoped>
/* 图标大小 */
.icon-box {
    text-align: center;
    font-size: 40px;
}
li {
    list-style-type:none;
}
</style>