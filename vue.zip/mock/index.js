import Mock from 'mockjs'
import './home'
import './userlist'

Mock.setup({
timeout:'100-330'
})
